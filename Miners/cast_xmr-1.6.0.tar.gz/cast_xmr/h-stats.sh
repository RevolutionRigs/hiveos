#!/usr/bin/env bash

#######################
# MAIN script body
#######################

. /hive/custom/$CUSTOM_MINER/h-manifest.conf

#{
#	"total_hash_rate": 5255692,
#	"total_hash_rate_avg": 4982769,
#	"pool": {
#		"server": "eu-xmr.hiveon.net:12000",
#		"status": "connected",
#		"online": 13,
#		"offline": 0,
#		"reconnects": 0,
#		"time_connected": "2018-11-16 19:46:50",
#		"time_disconnected": "2018-11-16 19:46:49"
#	},
#	"job": {
#		"job_number": 1,
#		"difficulty": 100001,
#		"running": 13,
#		"job_time_avg": 0.00
#	},
#	"shares": {
#		"num_accepted": 0,
#		"num_rejected": 0,
#		"num_invalid": 0,
#		"num_network_fail": 0,
#		"num_outdated": 0,
#		"search_time_avg": 0.00
#	},
#	"devices": [
#	{
#		"device": "GPU0",
#		"device_id": 0,
#		"hash_rate": 881340,
#		"hash_rate_avg": 835376,
#		"gpu_temperature": 45,
#		"gpu_fan_rpm": 2881
#	},
#	{
#		"device": "GPU1",
#		"device_id": 1,
#		"hash_rate": 881138,
#		"hash_rate_avg": 835178,
#		"gpu_temperature": 48,
#		"gpu_fan_rpm": 2997
#	},
#	{
#		"device": "GPU2",
#		"device_id": 2,
#		"hash_rate": 863892,
#		"hash_rate_avg": 820512,
#		"gpu_temperature": 46,
#		"gpu_fan_rpm": 2940
#	},
#	{
#		"device": "GPU3",
#		"device_id": 3,
#		"hash_rate": 881542,
#		"hash_rate_avg": 834716,
#		"gpu_temperature": 47,
#		"gpu_fan_rpm": 2867
#	},
#	{
#		"device": "GPU4",
#		"device_id": 4,
#		"hash_rate": 881745,
#		"hash_rate_avg": 835773,
#		"gpu_temperature": 47,
#		"gpu_fan_rpm": 2953
#	},
#	{
#		"device": "GPU5",
#		"device_id": 5,
#		"hash_rate": 866035,
#		"hash_rate_avg": 821214,
#		"gpu_temperature": 46,
#		"gpu_fan_rpm": 2974
#	}
#	]
#}

# 0 = CryptoNight
# 1 = CryptoNightV7
# 2 = CryptoNight-Heavy
# 3 = CryptoNight-Lite
# 4 = CryptoNightV7-Lite
# 5 = CryptoNightTUBE-Heavy
# 6 = CryptoNightXTL
# 7 = CryptoNightXHV-Heavy
# 8 = CryptoNight-Fast
# 9 = CryptoNightFEST
# 10 = CryptoNightV8

stats_raw=`curl --connect-timeout 2 --max-time $API_TIMEOUT --silent --noproxy '*' http://127.0.0.1:15750`
if [[ $? -ne 0 || -z $stats_raw ]]; then
	echo -e "${YELLOW}Failed to read $miner from localhost:15750${NOCOLOR}"
else
	khs=`echo $stats_raw | jq -r '.total_hash_rate / 1000 / 1000'`

	local temp=`echo $stats_raw | jq -r '.devices[].gpu_temperature' | jq -cs '.'`
	local ac=$(jq '.shares.num_accepted' <<< "$stats_raw")
	local rj=$(jq '.shares.num_rejected' <<< "$stats_raw")
	local hs=`echo $stats_raw | jq -r '.devices[].hash_rate' | jq -cs '.'`
	local algo_num=`grep -oP '(\-\-algo|\-a).+(\d+?)' $CUSTOM_CONFIG_FILENAME | tr -d '\-=[a-z]' | sed 's/^ *//'`

	local rpm=""
	local fanspeeds=""

	# Hack to convert RPM to percentages(ish)
	for rpm in $(echo $stats_raw | jq -r '.devices[].gpu_fan_rpm'); do
		fanspeeds+="$(echo $rpm 4850 | awk '{ printf("%.2f\n",$1/$2) }' | cut -f2 -d.) "
	done

	local fan=`echo $fanspeeds | jq -cs '.'`

	# Algorithms I know about
	case $algo_num in
		0) algo="cryptonight" ;;
		1) algo="cryptonight-v7" ;;
		10) algo="cryptonight-v8" ;;
	esac

	stats=$(jq --argjson temp "$temp" --argjson fan "$fan" --arg ac "$ac" \
		--arg rj "$rj" --argjson hs "$hs" --arg hs_units "hs" \
		--arg algo "$algo" \
		'{algo: $algo, hs_units: $hs_units, hs: $hs, hs_units: $hs_units, $temp, $fan, uptime: .pool.online, ar: [$ac, $rj]}' \
	 <<< "$stats_raw")
fi

[[ -z $khs ]] && khs=0
[[ -z $stats ]] && stats="null"

